$(function(){
	/*$(document.body).toggle( function() {
		var frameset = window.parent.document.getElementById("framesetCols");
		frameset.cols = "0px,8px,*";
		$("#bottom_center").attr("class", "botton_right");
	}, function() {
		var frameset = window.parent.document.getElementById("framesetCols");
		frameset.cols = "215px,8px,*";
		$("#bottom_center").attr("class", "bottom_left");
	});*/
});