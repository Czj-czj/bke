var Constant={
		
    
	passwordConfirmMsg:"确认要重置密码吗？",
	passwordErrMsg:"请选择要重置密码的选项？",
	
	ableConfigMsg:"确定要批量启动吗？",
	ableErrMsg:"请选择要启用的项",
	disableConfigMsg:"确定要禁用吗？",
	disableErrMsg:"请选择要禁用的项",
	delConfigMsg:"确定要删除吗？",
	delErrMsg:"请选择要删除的项",
	
	enableConfigMsg:"确定要启用吗？",
	
	passConfigMsg:"确定要通过吗？",
	passErrMsg:"请选择要通过的项",
	
	isAdConfigMsg:"确定要设为广告吗？",
	isAdErrMsg:"请选择具体的项",
	
	isNotAdConfigMsg:"确定要取消广告吗？",
	
	nopassConfigMsg:"确定要不通过吗？",
	nopassErrMsg:"请选择要不通过的项",
		
	nopassUpdateConfigMsg:"确定要批量不批准修改吗？",
	nopassUpdateErrMsg:"请选择要修改的数据项"	,
	
	passUpdateConfigMsg:"确定要批量批准修改吗？",
	passUpdateErrMsg:"请选择要修改的数据项"	,
		
	releaseConfigMsg:"确定要批量发布操作吗？",
	releaseErrMsg:"请选择要发布的数据项",
	
	isShowConfigMsg:"确定要批量操作吗？",
	isShowErrMsg:"请选择要操作的数据项",
		
	revokeConfigMsg:"确定要批量撤销操作吗？",
	revokeErrMsg:"请选择要撤销的数据项",
		
	translateConfigMsg:"确定要批量翻译操作吗？",
	translateErrMsg:"请选择要翻译的数据项",
		
	paperConfigMsg:"确定要批量确认交稿操作吗？",
	paperErrMsg:"请选择要确认交稿的数据项"
		
};