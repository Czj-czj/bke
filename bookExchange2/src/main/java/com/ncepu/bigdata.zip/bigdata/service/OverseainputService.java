package com.ncepu.bigdata.service;

import com.ncepu.bigdata.entity.Overseasinput;

import java.util.Date;
import java.util.List;

public interface OverseainputService {
    public List<Overseasinput> getAll();
    public Overseasinput getosinOne(int pid);
    public Overseasinput getUser(int uid);
    public void updateUser(Overseasinput overseasinput);
    public void insertUser(Overseasinput overseasinput);
    public void deleOne(int uid);
    public void deleSome(String[] uids);
    public List<Overseasinput> getOsin(Date time,String province);
    public void upOsin(Overseasinput overseasinput);
}
