package com.ncepu.bigdata.entity;

/**
 * 角色实体类
 */
public class Role {

    private int rid;//角色编号
    private String rname;//角色名称
    private String rdesc;//角色标识

    public Role() {
    }

    public Role(int rid, String rname, String rdesc) {
        this.rid = rid;
        this.rname = rname;
        this.rdesc = rdesc;
    }

    public int getRid() {
        return rid;
    }

    public void setRid(Integer rid) {
        this.rid = rid;
    }

    public String getRname() {
        return rname;
    }

    public void setRname(String rname) {
        this.rname = rname;
    }

    public String getRdesc() {
        return rdesc;
    }

    public void setRdesc(String rdesc) {
        this.rdesc = rdesc;
    }
}
