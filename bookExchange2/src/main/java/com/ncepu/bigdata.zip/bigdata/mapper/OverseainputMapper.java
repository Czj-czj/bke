package com.ncepu.bigdata.mapper;

import com.ncepu.bigdata.entity.Overseasinput;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Mapper  //使用注解完成SQL语句
@Repository  //将当前的mapper添加到容器当中并且是持久层的功能
public interface OverseainputMapper {
    @Select("SELECT * FROM t_covid19_overseasinput")
    List<Overseasinput> overSeaAll();

    @Select("<script>" +
            " select * from t_covid19_overseasinput" +
            " <where>" +
            " <if test = 'time != null'>" +
            " and time = #{time}" +
            "</if>" +
            "<if test = 'province != \"\"'>" +
            " and provinceShortName = #{province}" +
            " </if>" +
            " </where>" +
            " </script>")
    List<Overseasinput> getOsin(@Param("time") Date time,@Param("province") String province);

    @Select("select * from t_covid19_overseasinput where pid = #{pid}")
    Overseasinput getOsinOne(@Param("pid") int pid);

    @Update("update t_covid19_overseasinput set " +
            "pid=#{pid} ," +
            "provinceShortName = #{provinceShortName} ," +
            "confirmedCount=#{confirmedCount} ," +
            "time=#{datetime} ," +
            "datetime=#{datetime} " +
            "where uid = #{uid}")
    void upOsin(Overseasinput overseasinput);


}
