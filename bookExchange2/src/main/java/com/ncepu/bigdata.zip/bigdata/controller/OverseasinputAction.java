package com.ncepu.bigdata.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ncepu.bigdata.entity.Overseasinput;
import com.ncepu.bigdata.entity.Role;
import com.ncepu.bigdata.entity.SysUser;
import com.ncepu.bigdata.service.serviceImpl.OverseasinputServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.Date;
import java.util.List;

@Controller
public class OverseasinputAction {
    @Autowired
    OverseasinputServiceImpl overseainputServiceImpl;

    @RequestMapping("/overSeaAll")
    public String overSeaAll(Model model, Integer page){
        List<Overseasinput> overseasinputs=overseainputServiceImpl.getAll();
        if(page==null)
            page=1;
        PageHelper.startPage(page,1);
        PageInfo<Overseasinput> pageInfo=new PageInfo<>(overseasinputs);
        model.addAttribute("info",pageInfo);
        model.addAttribute("ova",overseasinputs);
        return "overseasinput/overseasinputList.html";
    }
    @RequestMapping("/getOsin")
    public String getRoles(Model model, Date time,String provinceShortName,Integer page){
        List<Overseasinput> overseasinputs=overseainputServiceImpl.getOsin(time,provinceShortName);
        if(page==null)
            page=1;
        PageHelper.startPage(page,1);
        PageInfo<Overseasinput> pageInfo=new PageInfo<>(overseasinputs);
        model.addAttribute("info",pageInfo);
        model.addAttribute("ova",overseasinputs);
        return "overseasinput/overseasinputList.html";
    }

    @RequestMapping("/overseasinputgetOne")
    public String overseasinputGetOne(Model model,int pid,int flag){
        Overseasinput overseasinputs=overseainputServiceImpl.getosinOne(pid);
        model.addAttribute("ova",overseasinputs);
        if(flag==0)
        return "overseasinput/detailOverseasinput.html";
        else
            return "overseasinput/updateOverseasinput.html";
    }

    @RequestMapping("/updateOverseasinput")
    public String upOsin(int pid,Overseasinput overseasinput){
        overseainputServiceImpl.upOsin(overseasinput);
        return "forward:/getOsin";
    }
}
