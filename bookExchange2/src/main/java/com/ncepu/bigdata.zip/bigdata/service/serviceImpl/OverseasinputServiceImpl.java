package com.ncepu.bigdata.service.serviceImpl;

import com.ncepu.bigdata.entity.Overseasinput;
import com.ncepu.bigdata.mapper.OverseainputMapper;
import com.ncepu.bigdata.service.OverseainputService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Date;
import java.util.List;

@Service//将当前类标识为逻辑层的类,此时spring容器中有了当前类
@Transactional
public class OverseasinputServiceImpl implements OverseainputService {
    @Autowired
    OverseainputMapper overseainputMapper;
    @Override
    public List<Overseasinput> getAll() {
        return overseainputMapper.overSeaAll();
    }

    @Override
    public Overseasinput getosinOne(int pid) {
        return overseainputMapper.getOsinOne(pid);
    }

    @Override
    public Overseasinput getUser(int uid) {
        return null;
    }

    @Override
    public void updateUser(Overseasinput overseasinput) {

    }

    @Override
    public void insertUser(Overseasinput overseasinput) {

    }

    @Override
    public void deleOne(int pid) {

    }

    @Override
    public void deleSome(String[] pids) {

    }

    @Override
    public List<Overseasinput> getOsin(Date time, String province) {
        return overseainputMapper.getOsin(time,province);
    }

    @Override
    public void upOsin(Overseasinput overseasinput) {
         overseainputMapper.upOsin(overseasinput);
    }
}
