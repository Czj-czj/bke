package com.ncepu.bigdata.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.ncepu.bigdata.entity.Internalday;
import com.ncepu.bigdata.entity.Role;
import com.ncepu.bigdata.entity.SysUser;
import com.ncepu.bigdata.service.TuserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller
public class TuserAction {
    @Autowired
    TuserService tuserserviceImpl;
    /*
     *
     * @param go
     * @return
     * */
    @RequestMapping("/go")
    public String go(String go) {
        return go;
    }


    @RequestMapping("/login")
    public String login(String username, String password) {
        SysUser sysUser=tuserserviceImpl.login(username,password);
        String result="";
        if(sysUser==null){
            result="login.html";
        }else{
            result="main.html";
        }
        return result;
    }
    @RequestMapping("/getAll")
    public String getAll(Model model, Integer page){
        List<SysUser> users=tuserserviceImpl.getAll();
        if(page==null)
            page=1;
        PageHelper.startPage(page,1);
        PageInfo<SysUser> pageInfo=new PageInfo<>(users);
        model.addAttribute("info",pageInfo);
        model.addAttribute("us",users);
        return "user/userList.html";
    }


    @RequestMapping("/getRoles")
    public String getRoles(Model model){
        List<Role> roles=tuserserviceImpl.getRoles();
        model.addAttribute("rs",roles);
        return "role/roleList.html";
    }

    @RequestMapping("/getuser")
    public String getUser(String username,Model model){
        List<SysUser> users = tuserserviceImpl.getUser(username);
        model.addAttribute("us",users);
        return "user/userList.html";
    }
    @RequestMapping("/getRoleByName")
    public String getRoleByName(String rname,Model model){
        List<Role> roles = tuserserviceImpl.getRoleByName(rname);
        model.addAttribute("rs",roles);
        return "role/roleList.html";
    }

    @RequestMapping("/getOne")
    public String getOne(int uid,Model model,int flag){
        SysUser sysUser=tuserserviceImpl.getUser(uid);
        model.addAttribute("tuser",sysUser);
        if(flag==0){
        return "user/detailUser.html";
        }
        else{
            List<Role> roles=tuserserviceImpl.getRoles();
            model.addAttribute("role",roles);
            return "user/updateUser.html";
        }
    }

    @RequestMapping("/getValue")
    public String getValue(Model model){
        List<Internalday> internalday=tuserserviceImpl.getValue();
        model.addAttribute("as",internalday);
        return "view/nationalData.html";
    }
    @RequestMapping("/upUser")
    public String updateTuser(SysUser sysUser,int rid){
//        System.out.println(sysUser+","+rid);
        sysUser.getRole().setRid(rid);
        tuserserviceImpl.updateUser(sysUser);
        return "forward:/getAll";
    }
    @RequestMapping("/goAdd")
    public String goAdd(Model model){
        List<Role> roles = tuserserviceImpl.getRoles();
        model.addAttribute("roles",roles);
        return "user/addUser.html";
    }

    @RequestMapping("/addUser")
    public String addUser(SysUser sysUser,int rid){
        sysUser.getRole().setRid(rid);
        tuserserviceImpl.insertUser(sysUser);
        return "forward:/getAll";
    }

    @RequestMapping("/deleOne")
    public String deleOne(int uid){
        tuserserviceImpl.deleOne(uid);
        return "forward:/getAll";
    }

    @RequestMapping("/deleteUsers")
    public String deleSome(String uids){
        String[] ids=uids.split(",");
        tuserserviceImpl.deleSome(ids);
        return "forward:/getAll";
    }
}
